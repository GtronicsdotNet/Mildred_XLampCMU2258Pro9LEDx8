G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-05-02T11:01:42+02:00*
G04 #@! TF.ProjectId,PCBSupportoLenti,50434253-7570-4706-9f72-746f4c656e74,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-05-02 11:01:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
